extends Node2D


# Called when the nodCanvasItemers the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is te elapsed time since the previous frame.h
func _process(delta: float) -> void:
	if position < Vector2(0,0):position==Vector2(0,0)
 # Replace with function body.


func _on_cameracontrolup_pressed() -> void:
	position += Vector2(0,
	-10)
	# Replace with function body.


func _on_cameracontroldown_pressed() -> void:
	position += Vector2(0,10)# Replace with function body.


func _on_cameracontrolleft_pressed() -> void:
	position += Vector2(-10,0)# Replace with function body.


func _on_ccameracontrolright_pressed() -> void:
	position +=Vector2(10,0)# Replace with function body.
